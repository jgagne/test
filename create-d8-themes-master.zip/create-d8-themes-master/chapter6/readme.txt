// File: development.services.yml

# Local development services.
#
# To activate this feature, follow the instructions at the top of the
# 'example.settings.local.php' file, which sits next to this file.
services:
  cache.backend.null:
    class: Drupal\Core\Cache\NullBackendFactory

parameters:
  twig.config:
    debug: true
    auto_reload: true
    cache: false